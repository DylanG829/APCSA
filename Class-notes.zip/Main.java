class Main {
  public static void main(String[] args) {
    Student s1 = new Student();
    Student s2 = new Student("Alexa", 200);

    s1.setName("Mahika");

    System.out.println("s1 = " + s1.getName());
    System.out.println("s2 = " + s2.getName());
  }
}