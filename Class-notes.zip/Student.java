class Student {
  
  private String name;
  private double gpa;


  public Student(){
    this.name = "";
    this.gpa = 0;
  }
  public Student(String name, double gpa){
    this.name = name;
    this.gpa = gpa;
  }
  public String getName(){
    return this.name;
  }
  public void setName(String name){
    this.name = name; 
  }
  public double getGPA(){
    return this.gpa;
  }
  public void setGPA(double gpa){
    this.gpa = gpa; 
  }
}