import java.awt.*;
import java.awt.event.*;

public class Main extends Frame implements ActionListener
{
  Button btn = new Button("CHANGE COLOR");
  public Main(){
    setSize(500,500);
    setBackground(Color.blue);
    setLayout(new FlowLayout());
    add(btn);
    btn.addActionListener(this);
    setVisible(true);
  }
  public void actionPerformed(ActionEvent e){
    if(getBackground()==Color.blue)
      setBackground(Color.red);
      else
        setBackground(Color.blue);
      
    }
  
  public static void main(String[]args){
    Main m = new Main();
  }
}